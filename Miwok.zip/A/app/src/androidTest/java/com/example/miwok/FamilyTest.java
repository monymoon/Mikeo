package com.example.miwok;

import junit.framework.TestCase;

public class FamilyTest extends TestCase {

}