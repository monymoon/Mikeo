package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;

public class Family extends AppCompatActivity {
    private   word_adaptor q;
    private ArrayList<_word> words;
    private ListView ss;
    private MediaPlayer mediaPlayer;
    private ImageButton Player;
    private AudioManager audioManager;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);

        Player=(ImageButton)findViewById(R.id.stat);


        audioManager =(AudioManager) getSystemService(Context.AUDIO_SERVICE);

        words=new ArrayList<_word>();

        words.add(new _word("father", "әpә", R.drawable.family_father,R.raw.family_father));
        words.add(new _word("mother", "әṭa", R.drawable.family_mother,R.raw.family_mother));
        words.add(new _word("son", "angsi", R.drawable.family_son,R.raw.family_son));
        words.add(new _word("daughter", "tune", R.drawable.family_daughter,R.raw.family_daughter));
        words.add(new _word("older brother", "taachi", R.drawable.family_older_brother,R.raw.family_older_brother));
        words.add(new _word("younger brother", "chalitti", R.drawable.family_younger_brother,R.raw.family_younger_brother));
        words.add(new _word("older sister", "teṭe", R.drawable.family_older_sister,R.raw.family_older_sister));
        words.add(new _word("younger sister", "kolliti", R.drawable.family_younger_sister,R.raw.family_younger_sister));
        words.add(new _word("grandmother ", "ama", R.drawable.family_grandmother,R.raw.family_grandmother));
        words.add(new _word("grandfather", "paapa", R.drawable.family_grandfather,R.raw.family_mother));



        q = new word_adaptor(words,getBaseContext(),R.color.category_colors);

        ss=findViewById(R.id.list);
        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        ss.setAdapter(q);

}}