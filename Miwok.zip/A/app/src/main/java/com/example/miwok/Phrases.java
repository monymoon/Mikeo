package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Phrases extends AppCompatActivity {
    private   word_adaptor q;
    private ArrayList<_word> words;
    private ListView ss;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);
        words=new ArrayList<_word>();


        words.add(new _word("Where are you going?", "minto wuksus",R.raw.phrase_where_are_you_going));
        words.add(new _word("What is your name?", "tinnә oyaase'nә",R.raw.phrase_what_is_your_name));
        words.add(new _word("My name is...", "oyaaset...",R.raw.phrase_my_name_is));
        words.add(new _word("How are you feeling?", "michәksәs?",R.raw.phrase_how_are_you_feeling));
        words.add(new _word("I’m feeling good.", "kuchi achit",R.raw.phrase_im_feeling_good));
        words.add(new _word("Are you coming?", "әәnәs'aa?",R.raw.phrase_are_you_coming));
        words.add(new _word("Yes, I’m coming.", "hәә’ әәnәm",R.raw.phrase_yes_im_coming));
        words.add(new _word("Let’s go.", "yoowutis",R.raw.phrase_lets_go));
        words.add(new _word("Come here.", "әnni'nem",R.raw.phrase_come_here));

        q = new word_adaptor(words,getBaseContext(),R.color.category_colors);

        ss=findViewById(R.id.list);
        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        ss.setAdapter(q);
    }
}