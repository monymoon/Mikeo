package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Color extends AppCompatActivity {
    private   word_adaptor q;
    private ArrayList<_word> words;
    private ListView ss;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);
        words=new ArrayList<_word>();

        words.add(new _word("red", "weṭeṭṭi", R.drawable.color_red,R.raw.color_red));
        words.add(new _word("dusty yellow", "ṭopiisә", R.drawable.color_dusty_yellow,R.raw.color_dusty_yellow));
        words.add(new _word("green", "chokokki", R.drawable.color_green,R.raw.color_green));
        words.add(new _word("brown", "ṭakaakki", R.drawable.color_brown,R.raw.color_brown));
        words.add(new _word("gray", "ṭopoppi", R.drawable.color_gray,R.raw.color_gray));
        words.add(new _word("black", "kululli", R.drawable.color_black,R.raw.color_black));
        words.add(new _word("white", "kelelli", R.drawable.color_white,R.raw.color_white));

        q = new word_adaptor(words,getBaseContext(),R.color.category_colors);

        ss=findViewById(R.id.list);
        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        ss.setAdapter(q);


    }

}