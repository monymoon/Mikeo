package com.example.miwok;

public class _word {
    private String frist_lun;
    private String sucand_lun;
    private static final int NO_IMAGE_PROVIDED=-1;
    private int image=NO_IMAGE_PROVIDED;
    private int SONG;

    public _word( String sucand_lun,String frist_lun,int SONG) {
        this.frist_lun = frist_lun;
        this.sucand_lun = sucand_lun;
        this.SONG=SONG;

    }

    public int getSONG() {
        return SONG;
    }

    public void setSONG(int SONG) {
        this.SONG = SONG;
    }

    public _word(String sucand_lun, String frist_lun, int image, int SONG) {
        this.frist_lun = frist_lun;
        this.sucand_lun = sucand_lun;
        this.image = image;
        this.SONG=SONG;
    }

    public String getFrist_lun() {
        return frist_lun;
    }



    public String getSucand_lun() {
        return sucand_lun;
    }


    public int getImage() {
        return image;
    }
    public boolean has_Image() {
        return image != NO_IMAGE_PROVIDED;
    }

}
