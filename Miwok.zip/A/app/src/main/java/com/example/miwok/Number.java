package com.example.miwok;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class Number extends AppCompatActivity {
    private   word_adaptor q;
    private ArrayList<_word> words;
  private   ListView ss;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view);
        words=new ArrayList<_word>();
        words.add(new _word("one", "lutti", R.drawable.number_one,R.raw.number_one));
        words.add(new _word("two", "otiiko", R.drawable.number_two,R.raw.number_two));
        words.add(new _word("three", "tolookosu", R.drawable.number_three,R.raw.number_three));
        words.add(new _word("four", "oyyisa", R.drawable.number_four,R.raw.number_four));
        words.add(new _word("five", "massokka", R.drawable.number_five,R.raw.number_five));
        words.add(new _word("six", "temmokka", R.drawable.number_six,R.raw.number_six));
        words.add(new _word("seven", "kenekaku", R.drawable.number_seven,R.raw.number_seven));
        words.add(new _word("eight", "kawinta", R.drawable.number_eight,R.raw.number_eight));
        words.add(new _word("nine", "wo’e", R.drawable.number_nine,R.raw.number_nine));
        words.add(new _word("ten", "na’aacha", R.drawable.number_ten,R.raw.number_ten));
        q = new word_adaptor(words,getBaseContext(),R.color.category_numbers);

        // Find the {@link ListView} object in the view hierarchy of the {@link Activity}.
        // There should be a {@link ListView} with the view ID called list, which is declared in the
        // word_list.xml layout file.

        ss=findViewById(R.id.list);
        // Make the {@link ListView} use the {@link WordAdapter} we created above, so that the
        // {@link ListView} will display list items for each {@link Word} in the list.
        ss.setAdapter(q);

    }
}